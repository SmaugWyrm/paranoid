#!/bin/bash
# Purge bloatware
apt purge libreoffice*
apt purge wolfram-engine
apt purge minecraft-pi
apt purge sonic-pi
apt autoremove
# Update system
apt-get update
apt-get upgrade
# Install Navigation packages
apt-get install minicom
apt-get install navit unclutter
apt-get install espeak
